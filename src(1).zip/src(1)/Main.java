package org.max;

import java.io.IOException;
import java.util.ArrayList;


public class Main{

    public static void main(String[] args) throws IOException {

        /* Une seule simulation */
//        ArrayList<Item> listItemP;
//        ArrayList<Rocket> pFleetU;
//
//        int k;
//        int nb_types_fusees = 2; // Nous avons seulement U1 et U2, mais si nous voulons faire des combinaisons d'équipements pour créer des fusées U3 U4 etc. il suffira de changer ce nombre pour que le programme les traite tous.
//
//        for (k=1;k<=nb_types_fusees;k++) {
//
//            Simulation simulation = new Simulation();
//
//            listItemP = Simulation.loadItems("C:/ENSTA Bretagne/2A/Semestre 3/Java/Projet/Projet-Java/Projet_Mars/files/listNoe.txt");
//            pFleetU = simulation.loadUX(listItemP,k);
//            int n_rocket= simulation.runSimulation(pFleetU);
//            double p1BudgetU = simulation.getBudgetRocket();
//            double p1BudgetCargoU = simulation.getBudgetCargo();
//            double rocketExplosee1 = simulation.getNbRocketExplosee();
//
//            System.out.println("************************ Début Phase - U" + k + " *****************************");
//            System.out.println("nombre de rockets U" + k + " utilisées:");
//            System.out.println(n_rocket);
//            System.out.println("nombre de rockets ayant explosées");
//            System.out.println(rocketExplosee1);
//            System.out.println("budget des rockets phase 1 avec U" + k + " (en million de $):");
//            System.out.println(p1BudgetU);
//            System.out.println("budget des items phase 1 avec U" + k + " (en million de $):");
//            System.out.println(p1BudgetCargoU);
//            System.out.println("budget total phase 1 avec U" + k + " (en million de $):");
//            System.out.println(p1BudgetU+p1BudgetCargoU);
//            System.out.println("************************ Fin Phase - U" + k + " *****************************");
//            System.out.println("");
//        }

        /* simulation x100 approfondie */
        ArrayList<Item> listItemP;
        ArrayList<Rocket> pFleetU;

        int k,i;
        int nb_types_fusees = 2; // Nous avons seulement U1 et U2, mais si nous voulons faire des combinaisons d'équipements pour créer des fusées U3 U4 etc. il suffira de changer ce nombre pour que le programme les traite tous.

        for (k = 1; k <= nb_types_fusees; k++) {

            double n_rocket=0;
            double p1BudgetU=0;
            double p1BudgetCargoU=0;
            double rocketExplosee1=0;

            System.out.println("************************ Début Phase x100 Simulations - U" + k + " *****************************");

            /* Nous faisons 100 simulations moyennées pour avoir des résultats un peu plus précis */
            for (i=0;i<100;i++) {

                Simulation simulation = new Simulation();

                listItemP = simulation.loadItems("C:/ENSTA Bretagne/2A/Semestre 3/Java/Projet/Projet-Java/Projet_Mars/files/listNoe.txt");
                pFleetU = simulation.loadUX(listItemP, k);

                n_rocket += simulation.runSimulation(pFleetU);
                p1BudgetU += simulation.getBudgetRocket();
                p1BudgetCargoU += simulation.getBudgetCargo();
                rocketExplosee1 += simulation.getNbRocketExplosee();

            }

            System.out.println("nombre de rockets moyen U" + k + " utilisées:");
            System.out.println(n_rocket/100);
            System.out.println("nombre de rockets moyen ayant explosées");
            System.out.println(rocketExplosee1/100);
            System.out.println("budget moyen des rockets phase 1 avec U" + k + " (en million de $):");
            System.out.println(p1BudgetU/100);
            System.out.println("budget moyen des items phase 1 avec U" + k + " (en million de $):");
            System.out.println(p1BudgetCargoU/100);
            System.out.println("budget moyen total phase 1 avec U" + k + " (en million de $):");
            System.out.println(p1BudgetU/100 + p1BudgetCargoU/100);
            System.out.println("************************ Fin Phase x100 Simulations - U" + k + " *****************************");
            System.out.println("");
        }

//    // Test de la distribution de probabilité
//        System.out.println("------------------Phase de test de la distribution de probabilité--------------------------");
//        // on créé une liste  de  10000 items de poids de la taille de cargo max et on charge donc 100 fusées et on regarde combien d'entre elles explosent
//        ArrayList<Item> listItemTest = simulation.loadItems("C:/ENSTA Bretagne/2A/Semestre 3/Java/Projet/Projet-Java/Projet_Mars/files/listItemsTest");
//        ArrayList<Rocket> testFleetU1 = simulation.loadUX(listItemTest,1);
//
//        double testBudgetU1 = simulation.runSimulation(testFleetU1);
//        double rocketExplosee = simulation.getNbRocketExplosee();
//
//        System.out.println("nb de rockets remplie: ");
//        System.out.println(testFleetU1.size());
//        System.out.println("nb de rockets qui ont explosées : ");
//        System.out.println(rocketExplosee);
//        System.out.println("Cela représente environ (en %) ");
//        System.out.println(100.0*rocketExplosee/testFleetU1.size());


    }
}