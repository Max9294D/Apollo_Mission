package org.max;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class RocketTest {
    Item item1 = new Item("item",500,0);
    Item item2 = new Item("item2",1500,0);

    Rocket rocket = new Rocket(10,1000,2000,0,0);


    @Test
    @DisplayName("canCarry Test")
    void canCarry() {
        assertTrue(rocket.canCarry(item1)); // on vérifie que la rocket peut transporter l'item
        assertFalse(rocket.canCarry(item2)); // on vérifie que la rocket ne peut pas transporter l'item 2 car il est trop lourd
    }

    @Test
    @DisplayName("carry Test")
    void carry() {
        rocket.carry(item1);
        assertEquals(500.0, rocket.getCargoCarried()); //on vérifie que le poid transporté est de 500
        assertEquals(1500.0, rocket.getWeight()); //on vérifie que le poid total de la fusée + cargo est de 1500
    }
}

// tester la distribution de probabilité on fixxe le rapport de cargo transporté sur le poids maximal et on effectue bcp
// de simulation en comptant le nb de fusée qui explose et on regarde si cela correspond bien à la valeur attendue