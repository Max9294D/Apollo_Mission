package org.max;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Collections;

public class Simulation {
    Rocket rocket;
    private double budgetRocket = 0;
    private double budgetCargo =0;
    private double nbRocketExplosee = 0;
    private double coutSupp = 0;
    private ArrayList<Item> itemsList;

    //Constructeur
    public Simulation(){
        itemsList = new ArrayList<Item>();
    }

    //Getters et Setters
    public double getBudgetRocket() { return budgetRocket; }
    public void setBudgetRocket(double budgetRocket) { this.budgetRocket = budgetRocket; }

    public double getBudgetCargo() { return budgetCargo; }
    public void setBudgetCargo(double budgetCargo) { this.budgetCargo = budgetCargo; }

    public double getNbRocketExplosee() { return nbRocketExplosee; }
    public void setNbRocketExplosee(double nbRocketExplosee) { this.nbRocketExplosee = nbRocketExplosee; }

    public double getCoutSupp() { return coutSupp; }
    public void setCoutSupp(double cout_supp) { this.coutSupp = cout_supp; }



    static ArrayList loadItems(String textFile){
        ArrayList liste = new ArrayList();

        try{
            File myObj = new File(textFile);
            Scanner myReader = new Scanner(myObj);
            while(myReader.hasNextLine()){
                String data = myReader.nextLine();
                liste.add(data);
            }
            myReader.close();
        }
        catch (FileNotFoundException e){
            System.out.println("an error happened");
            e.printStackTrace();
        }
        Object[] liste2 = liste.toArray();
        ArrayList<Item> items = new ArrayList();
        int i;
        for (i=0; i<liste.size(); i++){
            String[] item = liste2[i].toString().split("=",5);
            items.add(new Item(item[0],Integer.parseInt(item[1]),Integer.parseInt(item[2])));
        }
        return items;
    }




//// 2 méthodes: une pour charger des fusées u1 et une pour charger des fusées u2
//    public ArrayList loadU1(ArrayList<Item> listItems){
//        ArrayList<U1> listU1 = new ArrayList<>();
//        listU1.add(new U1());
//        int size_item = listItems.size();
//        for (int i = 0; i < size_item; i++) {
//            int compteur = 1;
//
//            /* On décrit la liste des fusée diponibles */
//            for (int k = 0; k < listU1.size();k++) {
//                if (listU1.get(k).canCarry(listItems.get(i))) {
//                    listU1.get(k).carry(listItems.get(i));
//                    break;
//                }
//                if (compteur == listU1.size()) {
//                    listU1.add(new U1());
//                    listU1.get(compteur).carry(listItems.get(i));
//                    break;
//                }
//                compteur++;
//            }
//        }
//        return listU1;
//    }
//
//
//    public ArrayList loadU2(ArrayList<Item> listItems){
//        ArrayList<U2> listU2 = new ArrayList<>();
//        listU2.add(new U2());
//        int size_item = listItems.size();
//        for (int i = 0; i < size_item; i++) {
//            int compteur = 1;
//
//            /* On décrit la liste des fusée diponibles */
//            for (int k = 0; k < listU2.size();k++) {
//                if (listU2.get(k).canCarry(listItems.get(i))) {
//                    listU2.get(k).carry(listItems.get(i));
//                    break;
//                }
//                if (compteur == listU2.size()) {
//                    listU2.add(new U2());
//                    listU2.get(compteur).carry(listItems.get(i));
//                    break;
//                }
//                compteur++;
//            }
//        }
//        return listU2;
//    }



    // 1 méthode qui charge les 2 types de fusées en donnant en 2ème indice l'indice de la fusée
    public ArrayList loadUX(ArrayList<Item> listItems, int X) { // X donne l'indice de la fusée X=1 -> U1 et X=2 -> U2
        ArrayList<ArrayList<Equipment>> listEquipment = new ArrayList<>();

        ArrayList<Equipment> listEquipmentU1 = new ArrayList<>();
        ArrayList<Equipment> listEquipmentU2 = new ArrayList<>();

        // Ajout du modèle pour U1
        listEquipmentU1.add(new Equipment("TTU1","T",20,1,2500,4000,1));
        listEquipmentU1.add(new Equipment("CPU1","C",30, 1,3500,14000,1));
        listEquipmentU1.add(new Equipment("RRU1","R",50, 1,4000,0,5));
        listEquipment.add(listEquipmentU1);

        // Ajout du modèle pour U2
        listEquipmentU2.add(new Equipment("TTU2","T",15,2,2500,7000,10));
        listEquipmentU2.add(new Equipment("CPU2","C",45, 2,6500,22000,6));
        listEquipmentU2.add(new Equipment("RRU2","R",60, 2,9000,0,4));
        listEquipment.add(listEquipmentU2);


        if (X>listEquipment.size()) {
            System.out.println("Le modèle de fusée demandé n'est pas valide");
            ArrayList<Rocket> listVide = new ArrayList<>();
            return listVide;
        }
        else{
            ArrayList<Equipment> listEquipmentAux = new ArrayList<>();
            ArrayList<U> listU = new ArrayList<>();
            listEquipmentAux = listEquipment.get(X-1); // 0 -> U1, 1 -> U2 etc
            listU.add(new U(listEquipmentAux.get(0),listEquipmentAux.get(1),listEquipmentAux.get(2)));

            int size_item = listItems.size();

            for (int p = 0; p < size_item - 1; p++)
            {
                int index = p;
                for (int j = p + 1; j < size_item; j++)
                {
                    if (listItems.get(j).getCost()/listItems.get(j).getWeight() > listItems.get(index).getCost()/listItems.get(index).getWeight()){
                        index = j;
                    }
                }
                Collections.swap(listItems, index, p);
            }

            for (int i = 0; i < size_item; i++) {
                int compteur = 1;

                /* On décrit la liste des fusées diponibles */
                for (int k = 0; k < listU.size(); k++) {

                    if (listU.get(k).canCarry(listItems.get(i))) {
                        listU.get(k).carry(listItems.get(i));
                        listU.get(k).setCostCargo(listU.get(k).getCostCargo() + listItems.get(i).getCost()); // on met à jour le prix de la cargaison
                        listU.get(k).addString((listItems.get(i).getName()));// on met à jour la liste de la cargaison
                        break;
                    }

                    /* Si tous les items ne sont pas chargés dans le nombre de fusées allouées, on en construit une autre */
                    if (compteur == listU.size()) {
                        listU.add(new U(listEquipmentAux.get(0), listEquipmentAux.get(1), listEquipmentAux.get(2)));
                        listU.get(compteur).carry(listItems.get(i));
                        listU.get(compteur).setCostCargo(listU.get(compteur).getCostCargo() + listItems.get(i).getCost()); // on met à jour le prix de la cargaison
                        listU.get(k).addString((listItems.get(i).getName())); // on met à jour la liste de la cargaison
                        break;
                    }
                    compteur++;

                }
            }
            return listU;
        }

    }


    public int runSimulation(ArrayList<Rocket> listRocket) throws IOException {
        int i;
        int n_fusee = 0;

        // on crée un fichier texte où l'on va répertorier tout le matériel perdu dans la rocket qui a explosée
        Path currentPath = Paths.get("");
        String s = currentPath.toAbsolutePath().toString();
        Path path = Paths.get(s,"objets_perdus.txt");

        String texte = "****************** Nouveau Projet Mars **********************\nRépertoire des objets perdus lors de la mission :\n";

        // si on veut garder l'historique des missions précédentes
        Files.write(path, texte.getBytes(), StandardOpenOption.CREATE, StandardOpenOption.WRITE, StandardOpenOption.APPEND);

        // si on ne veut pas garder l'historique de tentatives précédentes
        //Files.write(path, texte.getBytes());


        for (i=0;i<listRocket.size();){
            n_fusee++;
            //System.out.println(i);
            setBudgetRocket(getBudgetRocket()+listRocket.get(i).getCost());
            setBudgetCargo(getBudgetCargo()+listRocket.get(i).getCostCargo());

            /* Si la fusée décolle et attéri correctement on passe à la suivante */
            if (listRocket.get(i).launch() && listRocket.get(i).land()){
                i++;
            }

            /* Si la fusée se crash, alors on recréer la même fusée avec les mêmes items pour retenter de la faire partir */
            else
            {
                setNbRocketExplosee(getNbRocketExplosee()+1); // on incrémente le nb de rockets explosées
                setBudgetCargo(getBudgetCargo()+listRocket.get(i).getCostCargo()); // on met à jour le budget lié au cargo qui a explosé

                // on ajoute au fichier "objets_perdus.txt" la liste des items transportés par la fusée qui explose
                for(int j = 0;j<listRocket.get(i).getListCargo().size();j++)
                {
                    String nomObjet = listRocket.get(i).getListCargo().get(j);
                    String retourLigne ="\n";
                    Files.write(path, nomObjet.getBytes(), StandardOpenOption.CREATE, StandardOpenOption.WRITE, StandardOpenOption.APPEND);
                    Files.write(path, retourLigne.getBytes(), StandardOpenOption.CREATE, StandardOpenOption.WRITE, StandardOpenOption.APPEND);
                }

            }
        }

        //Mise en page du fichier texte en affichant le coût de chaque mission
        String annonceCoutFinal = "Le coût total de cette mission est (en million de $) : ";
        Files.write(path, annonceCoutFinal.getBytes(),StandardOpenOption.CREATE, StandardOpenOption.WRITE, StandardOpenOption.APPEND);
        String coutFinal = String.valueOf((int) getBudgetRocket()+getBudgetCargo());
        Files.write(path, coutFinal.getBytes(),StandardOpenOption.CREATE, StandardOpenOption.WRITE, StandardOpenOption.APPEND);
        String retourLigne ="\n";
        Files.write(path, retourLigne.getBytes(), StandardOpenOption.CREATE, StandardOpenOption.WRITE, StandardOpenOption.APPEND);
        String texteFin = "******************* Fin Projet Mars *****************\n";
        Files.write(path, texteFin.getBytes(), StandardOpenOption.CREATE, StandardOpenOption.WRITE, StandardOpenOption.APPEND);
        Files.write(path, retourLigne.getBytes(), StandardOpenOption.CREATE, StandardOpenOption.WRITE, StandardOpenOption.APPEND);
        Files.write(path, retourLigne.getBytes(), StandardOpenOption.CREATE, StandardOpenOption.WRITE, StandardOpenOption.APPEND);

        return n_fusee;
    }
}