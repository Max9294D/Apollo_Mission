package org.max;

public class Item {

    private String name;  //nom de l'item
    private int weight;  //poids de l'item
    private int cost; //coùt de l'item


    // constructeur
    public Item(String name, int weight, int cost) {
        this.name = name;
        this.weight = weight;
        this.cost = cost;
    }


    // getters et setters
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public int getWeight() {
        return weight;
    }
    public void setWeight(int weight) {
        this.weight = weight;
    }

    public int getCost() { return cost; }
    public void setCost(int cost) { this.cost = cost; }
}
