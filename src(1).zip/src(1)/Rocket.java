package org.max;


import java.util.ArrayList;

public class Rocket implements Spaceship{
    private double cost; // prix de la fusée
    private double weight;  // poids de la fusée
    private double maxWeight; // poids maximale de fusée + items transportés
    private double cargoCarried; // poids items transportés
    private double cargoLimit; // poids max des items transportés
    private double chanceExplo; // chance d'explosion
    private double chanceCrash; // chance de crash
    private double costCargo; // prix de l'intégralité de la cargaison
    private ArrayList<String> listCargo;  // liste de tous les objets en cargaison
    private ArrayList<String> listEquipment;  // liste de toutes les parties équipant la fusée, dans l'ordre la tête, le corps et les réacteurs

    //Constructeur

    public Rocket(double prix, double poids, double poidsMax, double chanceExplosion, double chanceCrashing) {
        cost = prix;
        weight = poids;
        maxWeight = poidsMax;
        chanceExplo = chanceExplosion;
        chanceCrash = chanceCrashing;
        cargoLimit = maxWeight - weight;
        cargoCarried = 0;
        costCargo = 0;
        listCargo = new ArrayList<String>();
    }


    // getters et setters

    public double getCost() { return cost; }
    public void setCost(double cost) { this.cost = cost; }

    public double getWeight() { return weight; }
    public void setWeight(double weight) { this.weight = weight; }

    public double getMaxWeight() { return maxWeight; }
    public void setMaxWeight(double max_weight) { this.maxWeight = max_weight; }

    public double getCargoCarried() { return cargoCarried; }
    public void setCargoCarried(double cargoCarried) { this.cargoCarried = cargoCarried; }

    public double getCargoLimit() { return cargoLimit; }
    public void setCargoLimit(double cargoLimit) { this.cargoLimit = cargoLimit; }

    public double getChanceExplo() { return chanceExplo; }
    public void setChanceExplo(double chanceExplo) { this.chanceExplo = chanceExplo; }

    public double getChanceCrash() { return chanceCrash; }
    public void setChanceCrash(double chanceCrash) { this.chanceCrash = chanceCrash; }

    public double getCostCargo() { return costCargo; }
    public void setCostCargo(double costCargo) { this.costCargo = costCargo; }

    public ArrayList<String> getListCargo() { return listCargo; }
    public void setListCargo(ArrayList<String> listCargo) { this.listCargo = listCargo; }

    public ArrayList<String> getListEquipment() { return listEquipment; }
    public void setListEquipment(ArrayList<String> listEquipment) { this.listEquipment = listEquipment; }

    //Méthode pour ajouter un élément à la liste de cargaison
    public void addString(String string) {
        this.listCargo.add(string);
    }

    //Méthode pour ajouter un équipement à la liste fusée de cargaison
    public void addEquipment(String string) {
        this.listEquipment.add(string);
    }

    // Méthodes
    @Override
    public boolean launch(){
        return true;
    }

    @Override
    public boolean land(){
        return true;
    }

    @Override
    public boolean canCarry(Item item){ //retourne si oui ou non la fusée peut transporter l'item
        return weight + item.getWeight() <= maxWeight;
    }

    @Override
    public void carry(Item item){
        if (canCarry(item))
        {
            setCargoCarried(getCargoCarried()+item.getWeight());
            setWeight(getWeight()+item.getWeight());
        }
        else{
            System.out.println("objet trop lourd");
        }
    }


}