package org.max;

public class Equipment {

    private String name; // Nom de l'équipement
    private String type; // Type de l'équipement (Tete, Corps, Reacteur)
    private int cost; // Coût de cet équipement
    private int num; // Numéro de la fusée (U1, U2 ...)
    private double weight; // Poids de l'équipement
    private double weightBonus; // Poids supplémentaire que cet équipement permet d'embarquer dans la fusée
    private double chanceDefect; // Probabilité d'avoir un défaut sur cet équipement

    // Constructeur
    public Equipment(String name, String type, int cost, int num, double weight, double weightBonus, double chanceDefect) {
        this.name = name;
        this.type = type;
        this.cost = cost;
        this.num = num;
        this.weight = weight;
        this.weightBonus = weightBonus;
        this.chanceDefect = chanceDefect;
    }

    // getters et setters
    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return this.type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getCost() {
        return this.cost;
    }

    public void setCost(int cost) {
        this.cost = cost;
    }

    public int getNum() {
        return this.num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public double getWeight() {
        return this.weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public double getWeightBonus() {
        return this.weightBonus;
    }

    public void setWeightBonus(double weightBonus) {
        this.weightBonus = weightBonus;
    }

    public double getChanceDefect() {
        return this.chanceDefect;
    }

    public void setChanceDefect(double chanceDefect) {
        this.chanceDefect = chanceDefect;
    }
}