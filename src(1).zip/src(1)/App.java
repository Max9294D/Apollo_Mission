package org.max;


import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class App extends Application {
    private Path pathResult;

    private Desktop desktop = Desktop.getDesktop();


//getter et setter
    public Path getPathResult() { return pathResult; }
    public void setPathResult(Path pathResult) { this.pathResult = pathResult; }

    @Override
    public void start(Stage primaryStage) throws Exception {

        final FileChooser fileChooser = new FileChooser();
        configuringFileChooser(fileChooser);



        Label intro1 = new Label("Bonjour jeune explorateur intergalactique !");
        Label intro2 = new Label("Ce programme permet de déterminer le budget de TA mission vers Mars !");
        Label intro3 = new Label("Pour que cela fonctionne rien de plus simple, il te suffit de charger ta liste d'objet");
        Label intro4 = new Label("Une fois dans l'espace pas de demi tour possible donc prend garde à ne rien oublier !");

        Label redactionListe1 = new Label("Etape 1 : rédige ta liste dans le même format que l'exemple suivant : objet=poids=pris");


        Label chargeListe = new Label("Etape 2 : charge ta liste :");


        TextArea textArea = new TextArea();
//        textArea.setMinHeight(70);


        Button button1 = new Button("Parcourir mon ordinateur");
        Button button2 = new Button("lancer la simulation".toUpperCase());
        Button button3 = new Button("lancer 100 simulations".toUpperCase());


        button1.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                textArea.clear();
                File file = fileChooser.showOpenDialog(primaryStage);
                if (file != null) {
                    Path path = Paths.get(file.getAbsolutePath());
                    setPathResult(path);
                    List<File> files = Arrays.asList(file);
                    printLog(textArea, files);
                }
            }
        });

        button2.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {

                ArrayList<Item> listItemP;
                ArrayList<Rocket> pFleetU;

                int k;
                int nb_types_fusees = 2;
                ArrayList<Double> budget = new ArrayList();
                ArrayList<Double> rocketExplo = new ArrayList();
                ArrayList<Integer> n_rocket = new ArrayList<>();

                for (k=1;k<=nb_types_fusees;k++) {

                    Simulation simulation = new Simulation();

                    listItemP = Simulation.loadItems(getPathResult().toString());
                    pFleetU = simulation.loadUX(listItemP,k);

                    try {
                         n_rocket.add(simulation.runSimulation(pFleetU));
                    } catch (IOException e) {
                         e.printStackTrace();
                    }
                    double p1BudgetU = simulation.getBudgetRocket();
                    double p1BudgetCargoU = simulation.getBudgetCargo();
                    double rocketExplosee1 = simulation.getNbRocketExplosee();



                    rocketExplo.add(rocketExplosee1);
                    budget.add((p1BudgetU + p1BudgetCargoU));

                }

                //Partie mise en page
                Stage newStage1 = new Stage();
                newStage1.setTitle("Projet Mars - Resultats");

                Label resultat = new Label("Résultats de la simulation");
                VBox root3 = new VBox();
                root3.setAlignment(Pos.CENTER);
                root3.setSpacing(5);



                Label budgetU1 = new Label("Budget de la simulation avec des fusées U1 (en millions) : " + budget.get(0) + " $");
                Label nbRocket1 = new Label("Nombre de fusées U1 utilisées : " +  n_rocket.get(0) );
                Label explosedU1 = new Label("Nombre de fusées U1 ayant explosées : " +  rocketExplo.get(0) );

                Label budgetU2 = new Label("Budget de la simulation avec des fusées U2 (en millions) : " + budget.get(1) + " $");
                Label nbRocket2 = new Label("Nombre de fusées U2 utilisées : " +  n_rocket.get(1) );
                Label explosedU2 = new Label("Nombre de fusées U2 ayant explosées : " +  rocketExplo.get(1) );

                root3.getChildren().addAll(budgetU1,nbRocket1,explosedU1,budgetU2,nbRocket2,explosedU2);

                root3.setAlignment(Pos.CENTER);
                root3.setSpacing(5);


                Scene scene2 = new Scene(root3, 750, 500);
                newStage1.setScene(scene2);
                newStage1.show();
                newStage1.centerOnScreen();

            }
        });

        button3.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {

                //Partie opérationnelle
                ArrayList<Item> listItemP;
                ArrayList<Rocket> pFleetU;

                int k, i;
                int nb_types_fusees = 2; // Nous avons seulement U1 et U2, mais si nous voulons faire des combinaisons d'équipements pour créer des fusées U3 U4 etc. il suffira de changer ce nombre pour que le programme les traite tous.
                ArrayList<Double> budget = new ArrayList();
                ArrayList<Double> rocketExplo = new ArrayList();


                for (k = 1; k <= nb_types_fusees; k++) {


                    double n_rocket = 0;
                    double p1BudgetU = 0;
                    double p1BudgetCargoU = 0;
                    double rocketExplosee1 = 0;


                    /* Nous faisons 100 simulations moyennées pour avoir des résultats un peu plus précis */
                    for (i = 0; i < 100; i++) {

                        Simulation simulation = new Simulation();

                        listItemP = simulation.loadItems(getPathResult().toString());
                        pFleetU = simulation.loadUX(listItemP, k);

                        try {
                            n_rocket += simulation.runSimulation(pFleetU);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        p1BudgetU += simulation.getBudgetRocket();
                        p1BudgetCargoU += simulation.getBudgetCargo();
                        rocketExplosee1 += simulation.getNbRocketExplosee();

                    }

                    rocketExplo.add(rocketExplosee1/100);
                    budget.add((p1BudgetU / 100 + p1BudgetCargoU / 100));

                }

                //Partie mise en page
                Stage newStage2 = new Stage();
                newStage2.setTitle("Projet Mars - Resultats");

                Label resultat = new Label("Résultats de la simulation");
                VBox root4 = new VBox();
                root4.setAlignment(Pos.CENTER);
                root4.setSpacing(5);

                Label budgetU1 = new Label("Budget moyen de la simulation avec 100 fusées U1 (en millions de $) : " + budget.get(0));
                Label explosedU1 = new Label("Nombre moyen de fusées U1 ayant explosées : " +  rocketExplo.get(0) );
                Label budgetU2 = new Label("Budget moyen de la simulation avec 100 fusées U2 (en millions de $) : " + budget.get(1));
                Label explosedU2 = new Label("Nombre moyen de fusées U2 ayant explosées : " +  rocketExplo.get(1) );

                root4.getChildren().addAll(budgetU1,explosedU1,budgetU2,explosedU2);

                Scene scene2 = new Scene(root4, 750, 500);
                newStage2.setScene(scene2);
                newStage2.show();
                newStage2.centerOnScreen();
            }
        });


        VBox root = new VBox();
        HBox root2 = new HBox();

        root.setPadding(new Insets(10));
        root.setAlignment(Pos.CENTER);
        root.setSpacing(5);

        root2.setPadding(new Insets(10));
        root2.setAlignment(Pos.CENTER);
        root2.setSpacing(5);

        root2.getChildren().addAll(button2,button3);
        root.getChildren().addAll(intro1,intro2,intro3,intro4,redactionListe1,chargeListe,textArea, button1, root2);


        Scene scene1 = new Scene(root, 750, 400);

        primaryStage.setTitle("Projet Mars");
        primaryStage.setScene(scene1);
        primaryStage.show();
        primaryStage.centerOnScreen();
    }

    private void printLog(TextArea textArea, List<File> files) {
        if (files == null || files.isEmpty()) {
            return;
        }
        for (File file : files) {
            textArea.appendText(file.getAbsolutePath() + "\n");
        }
    }



    public static void main(String[] args) throws IOException {
        Application.launch(args);
    }


    private void configuringFileChooser(FileChooser fileChooser) {
        // Set title for FileChooser
        fileChooser.setTitle("Select Text Document");

        // Set Initial Directory
        fileChooser.setInitialDirectory(new File("/home"));
        // Add Extension Filters
        fileChooser.getExtensionFilters().addAll(//
                new FileChooser.ExtensionFilter("TXT", "*.txt"));
    }

}




