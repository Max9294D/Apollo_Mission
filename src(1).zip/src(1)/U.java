package org.max;



public class U extends Rocket{

    public U(Equipment tete, Equipment corps, Equipment reacteur){
        super(tete.getCost() + corps.getCost() + reacteur.getCost(), // Prix = Prix de tous les équipements
                tete.getWeight() + corps.getWeight() + reacteur.getWeight(), // Poids = Poids de tous les équipements
                tete.getWeightBonus() + corps.getWeightBonus() + reacteur.getWeightBonus(), // PoidsMax IDEM
                reacteur.getChanceDefect(), // ChanceExplosion = Chance d'un défaut du réacteur
                (tete.getChanceDefect() + corps.getChanceDefect())/2); // ChanceCrashing = Moyenne chance défaut de la tête et du corps de la fusée
    }

    //Méthodes
    //Méthode launch initiale linéaire
//    public boolean launch(){
//        double probaExplo = (getChanceExplo()/100)*(this.getCargoCarried()/this.getCargoLimit());
//        if(Math.random()<probaExplo){ return false; }
//        else{ return true; }
//    }

    public boolean launch(){
        double probaExplo = (getChanceExplo()/100)*Math.pow((this.getCargoCarried()/this.getCargoLimit()),2);
        if(Math.random()<probaExplo){ return false; }
        else{ return true; }
    }

    //Méthode launch partie 3
//    public boolean launch(){
//        if(getCargoCarried()/getCargoLimit()<0.1) // si la fusée n'est remplie qu'à 10%
//        { if(Math.random()<0.01){ return false; } // on a 1% de chance d'explosion
//            else{ return true; } }
//
//        if(getCargoCarried()/getCargoLimit()<0.3 && getCargoCarried()/getCargoLimit()>=0.1) // si la fusée n'est remplie qu'à 30%
//        { if(Math.random()<0.05){ return false; } // on a 5% de chance d'explosion
//            else{ return true; } }
//
//        if(getCargoCarried()/getCargoLimit()<0.5 && getCargoCarried()/getCargoLimit()>=0.3) // si la fusée n'est remplie qu'à 50%
//        { if(Math.random()<0.1){ return false; } // on a 10% de chance d'explosion
//            else{ return true; } }
//
//        if(getCargoCarried()/getCargoLimit()<0.7 && getCargoCarried()/getCargoLimit()>=0.5) // si la fusée n'est remplie qu'à 70%
//        { if(Math.random()<0.2){ return false; } // on a 30% de chance d'explosion
//            else{ return true; } }
//
//        if(getCargoCarried()/getCargoLimit()<0.9 && getCargoCarried()/getCargoLimit()>=0.7) // si la fusée n'est remplie qu'à 90%
//        { if(Math.random()<0.25){ return false; } // on a 50% de chance d'explosion
//            else{ return true; } }
//
//        if(getCargoCarried()/getCargoLimit()==1) // si la fusée est remplie à 100%
//        { if(Math.random()<0.35){ return false; } // on a 75% ce chance d'explosion
//            else{ return true; } }
//
//        else{ return true; }
//    }


    public boolean land(){
        double probaCrash = (getChanceCrash()/100)*(this.getCargoCarried()/this.getCargoLimit());
        if(Math.random()<probaCrash){ return false; }
        else{ return true; }
    }
}